<?php
 /* Dados do Banco de Dados a conectar */
$Servidor = 'localhost';
$nomeBanco = 'banco_teste';
$Usuario = 'thiago';
$Senha = '123';
$strcon = mysqli_connect($Servidor, $Usuario, $Senha, $nomeBanco); 
?>