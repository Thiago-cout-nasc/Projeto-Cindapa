<?php
 // Conectando ao banco de dados:
 include_once("conectar.php");
 
 // Recebendo os dados a pesquisar
 $pesquisa = $_POST['caracteristica'];
?>

 <html>
 <head>
 <title>cadastro de veiculo</title>
 </head>
 <body>
 
 
 <tr>
 <th>chassi</th>
 <th>marca</th>
 <th>modelo</th>
 <th>ano</th>
 <th>placa</th>
 <th>caracteristica</th>
 </tr>
 
 <!-- Preenchendo a tabela com os dados do banco: -->
 <?php
 $sql = "SELECT * FROM cadastroveiculo WHERE caracteristica = '$pesquisa'";
 $resultado = mysqli_query($strcon,$sql) or die("Erro ao retornar dados");
 
 // Obtendo os dados por meio de um loop while
 while ($registro = mysqli_fetch_array($resultado))
 {
   $chassi = $registro['chassi'];
   $marca = $registro['marca'];
   $modelo = $registro['modelo'];
   $ano = $registro['ano'];
   $placa = $registro['placa'];
   $caracteristica= $registro['caracteristica'];
   
 }
 mysqli_close($strcon);
 echo "</table>";
?>

<?php
 $sql = "INSERT INTO cadastroveiculo (chassi,marca,modelo,ano,placa,caracteristica) VALUE(?,?,?,?,?,?)";
 $resultado = mysqli_query($strcon,$sql) or die("Erro");
 
 // Obtendo os dados por meio de um loop while
 while ($registro = mysqli_fetch_array($resultado))
 {
   $chassi = $registro['chassi'];
   $marca = $registro['marca'];
   $modelo = $registro['modelo'];
   $ano = $registro['ano'];
   $placa = $registro['placa'];
   $caracteristica= $registro['caracteristica'];
 }
 mysqli_close($strcon);
 echo "</table>";
?>


<?php
 $sql = "update cadastroveiculo  set chassi=?, marca=?, modelo=?, ano=?, placa=?, caracteristica=?, where id=?";
 $resultado = mysqli_query($strcon,$sql) or die("Erro");
 
 // Obtendo os dados por meio de um loop while
 while ($registro = mysqli_fetch_array($resultado))
 {
   $chassi = $registro['chassi'];
   $marca = $registro['marca'];
   $modelo = $registro['modelo'];
   $ano = $registro['ano'];
   $placa = $registro['placa'];
   $caracteristica= $registro['caracteristica'];
 }
 mysqli_close($strcon);
 echo "</table>";
?>

<?php
 $sql = "DELETE FROM cadastroveiculo  WHERE id = ?";
 $resultado = mysqli_query($strcon,$sql) or die("Erro");
 
 // Obtendo os dados por meio de um loop while
 while ($registro = mysqli_fetch_array($resultado))
 {
   $chassi = $registro['chassi'];
   $marca = $registro['marca'];
   $modelo = $registro['modelo'];
   $ano = $registro['ano'];
   $placa = $registro['placa'];
   $caracteristica= $registro['caracteristica'];
 }
 mysqli_close($strcon);
 echo "</table>";
?>

</body>
</html>